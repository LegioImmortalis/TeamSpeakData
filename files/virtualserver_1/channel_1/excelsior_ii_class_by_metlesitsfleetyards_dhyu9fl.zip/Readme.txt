
EXCELISOR-II CLASS

As seen in Star Trek: Picard.

Conditions of use:

Please put credits on the images made with this mesh, something like "Excelsior-II by David Metlesits", or similar.
You may use this mesh for any non-profit work.
You may edit, kitbash or do anything with this mesh. Just have fun with it :D

Live long and prosper!


David "KnightRider" Metlesits

